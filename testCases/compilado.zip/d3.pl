if(!5<6) print(a);
