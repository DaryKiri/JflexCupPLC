equis=64;
while(equis>1){
	print(equis=equis/2);
}
