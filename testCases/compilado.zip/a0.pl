print (0);
