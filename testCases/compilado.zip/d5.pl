if( 4 == 5 && (6 < 7)) print(b);
