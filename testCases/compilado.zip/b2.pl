{
   x=1;
   { 
   		y = 2;
   		{
   			x = 4;
   		}
   		z = 3;
   }
   	print (x);
   	print (y);
   	print (z);
}