f=1;
for(i=1; i<4; i=i+1){
	f=f*1;
}
print(f);
