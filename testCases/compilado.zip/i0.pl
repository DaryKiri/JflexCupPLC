i = 0;
if(i > 0){
	for(j=0;j < 10; j=j+1){
		print(j);
		i = i+1;
		if(i == 0){
			print(i);
		}else{
			print(j);
		}
	}
print(a);
}else{
	while(i > 10){
		print(i);
		i = i + 1;
	}
}
print(f);
