equis = 0;
while(equis < 10){
	while(equis == 20){
		print(2*4);
	}
	a = 0;
}
print(a);
